-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: i8a703.p.ssafy.io    Database: project1db
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `refresh_token`
--

DROP TABLE IF EXISTS `refresh_token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `refresh_token` (
  `token_id` int NOT NULL AUTO_INCREMENT,
  `refresh_token` varchar(160) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin NOT NULL,
  `user_id` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin NOT NULL,
  PRIMARY KEY (`token_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `refresh_token_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `member` (`user_id`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=813 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `refresh_token`
--

LOCK TABLES `refresh_token` WRITE;
/*!40000 ALTER TABLE `refresh_token` DISABLE KEYS */;
INSERT INTO `refresh_token` VALUES (608,'eyJhbGciOiJIUzI1NiJ9.eyJleHAiOjE2NzYxNDE0NzJ9.UPFy4OJzd4XGa2iQRqdlyBmkrpEAXxGSTdQjx021dCg','ssafy1'),(613,'eyJhbGciOiJIUzI1NiJ9.eyJleHAiOjE2NzYyNDM1MTJ9.BFoxIj1MNTELfkvFJKL3Nrd_lkxbpy0u3tGq93YuGHw','qweqwe'),(628,'eyJhbGciOiJIUzI1NiJ9.eyJleHAiOjE2NzYzMTM0Mzl9.KY3tl4yQRS-x39jYozBNYsHQ1qwitq0BrOok-fb9xvU','sessiontest'),(638,'eyJhbGciOiJIUzI1NiJ9.eyJleHAiOjE2NzYzMjQwMTB9.Bq_xrSJagsISgwc-ohOPI755HbebT1wHFkODLU3VGtA','aaaa'),(651,'eyJhbGciOiJIUzI1NiJ9.eyJleHAiOjE2NzYzOTczNzh9.MmkWGDOwBWJS-Bb2WBIJWNSsbCUkEe-3WI_pagOV_0U','sodjf1'),(692,'eyJhbGciOiJIUzI1NiJ9.eyJleHAiOjE2NzY0ODI1Nzd9.JJxeNYD8tkgMO9YOIYnvkoKsFy804ZVuPNxbeky0tqo','hansaema'),(715,'eyJhbGciOiJIUzI1NiJ9.eyJleHAiOjE2NzY0ODg0ODR9.GS4Pzs6mdXD4bXyHHS1YasZYKM_1ghGNuEGaJ6ap2PM','cheuora'),(746,'eyJhbGciOiJIUzI1NiJ9.eyJleHAiOjE2NzY0OTI2MDV9.p2OiAb5M3hgp9_tZJvDhrY6iLTI-8_SZ4q_ZsOM5TJY','si44440'),(761,'eyJhbGciOiJIUzI1NiJ9.eyJleHAiOjE2NzY1NDY5Mzl9.AEQIrDuJB80TJXyWFgL0voJGvFCDDKiRHqudsDjFhe8','sj3330'),(791,'eyJhbGciOiJIUzI1NiJ9.eyJleHAiOjE2NzY1NzI1MzN9.9nKnPfS0XRcEjxJpHKvDih_9ak5WcKuE6GbkZjTqyiY','ssafy2'),(795,'eyJhbGciOiJIUzI1NiJ9.eyJleHAiOjE2NzY1NzU5NzZ9.XqWlyYRppMI9Auug7qj0S_R5FFm56NFUx-Hp0PU6M6I','won1'),(796,'eyJhbGciOiJIUzI1NiJ9.eyJleHAiOjE2NzY1NzYwNTB9.zjrwn7UXBhdQbcsi1p2gJH-x02p5JACb8thnMU4SJBQ','byj99'),(797,'eyJhbGciOiJIUzI1NiJ9.eyJleHAiOjE2NzY1NzYwNTZ9.-Xd7yTOKDCRRVwXcN5jEJzuq9mECqfp0G_8cIdVNM8Q','sj444440'),(806,'eyJhbGciOiJIUzI1NiJ9.eyJleHAiOjE2NzY2MzU0ODV9.SAPaUCbM2T4HuPQ_C2B82x2ICk_Zb5F8g7rlqZE-mQY','leejiyeon'),(807,'eyJhbGciOiJIUzI1NiJ9.eyJleHAiOjE2NzY2NDExNjV9.72IQ92u1ETagy0MBB0gVd00NruEi9SyEiYWOh3Eh_uA','ssafy'),(808,'eyJhbGciOiJIUzI1NiJ9.eyJleHAiOjE2NzY2NDE0ODN9.LLjTSRvpbN2JDvyS9gJPzGMIRavyzg07byjrWJcxyps','jhyeop96'),(809,'eyJhbGciOiJIUzI1NiJ9.eyJleHAiOjE2NzY2NDE3NDh9.mDpozGbYleAf1fI1YWsuxvfOPYdZPhqBQe7CAvQ5EX4','sessiontest00'),(810,'eyJhbGciOiJIUzI1NiJ9.eyJleHAiOjE2NzY2NDMxODR9.8_Dp916i9UAKq7Rk-q1SsqlkyVMaP0GuI4E7zUVXBzY','바꾸바꾸'),(811,'eyJhbGciOiJIUzI1NiJ9.eyJleHAiOjE2NzY2NDM3NTV9.5EDC0EFP-eSahahZPb-zZCX4gTzPGKhWmv7yUujk1VI','asdf1234'),(812,'eyJhbGciOiJIUzI1NiJ9.eyJleHAiOjE2NzY2NDM4Njd9.PAai1pFc4Oqyb3nmTd-e-76nknyQyZ1rgsFmgHq62Sk','ksko8053');
/*!40000 ALTER TABLE `refresh_token` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-02-17 11:32:53
