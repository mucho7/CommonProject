-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: i8a703.p.ssafy.io    Database: project1db
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `comment`
--

DROP TABLE IF EXISTS `comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `comment` (
  `comment_id` int NOT NULL AUTO_INCREMENT,
  `board_id` int NOT NULL,
  `writer` varchar(32) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin NOT NULL,
  `content` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_bin DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `is_deleted` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`comment_id`),
  KEY `board_id` (`board_id`),
  KEY `comment_to_member_fk` (`writer`),
  CONSTRAINT `comment_ibfk_1` FOREIGN KEY (`board_id`) REFERENCES `board` (`board_id`),
  CONSTRAINT `comment_to_member_fk` FOREIGN KEY (`writer`) REFERENCES `member` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=137 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comment`
--

LOCK TABLES `comment` WRITE;
/*!40000 ALTER TABLE `comment` DISABLE KEYS */;
INSERT INTO `comment` VALUES (106,99,'ssafy','123','2023-02-13 04:47:46',0),(107,99,'ssafy','123','2023-02-13 04:50:04',0),(108,99,'ssafy','member','2023-02-13 04:51:06',0),(109,99,'ssafy','member','2023-02-13 05:35:15',0),(110,110,'ssafy','asd','2023-02-13 08:31:13',0),(111,116,'ssafy','세묘안녕하세묘안녕하세묘안녕하세묘안녕하세묘안녕하세묘안녕하세묘안녕하세묘안녕하세묘안녕하세묘안녕하세묘안녕하세묘안녕하세묘','2023-02-14 05:35:04',0),(112,116,'ssafy','aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa','2023-02-14 05:35:32',0),(113,130,'ssafy','asdf','2023-02-15 05:25:50',0),(114,130,'ssafy','asdf','2023-02-15 05:25:58',0),(115,130,'ssafy','qpweioruioajsdfkl;asjdf','2023-02-15 05:26:03',0),(116,130,'ssafy','zzzzzz','2023-02-15 05:26:19',0),(117,133,'byj99','eeerrr','2023-02-15 06:04:43',0),(118,133,'string','string','2023-02-15 06:06:03',1),(119,133,'si44440','string','2023-02-15 06:28:14',1),(120,133,'sj444440','r23r23r32','2023-02-15 06:40:25',0),(121,133,'sj444440','wdwedqwdq','2023-02-15 06:41:15',0),(122,133,'sj444440','wqqdw','2023-02-15 06:41:54',0),(123,133,'si44440','dwdwdwdwdw','2023-02-15 06:54:02',1),(124,133,'sj444440','댓글아 수정돼죠','2023-02-15 06:59:33',1),(125,134,'baba','ㅁㄴㅇㅁㄴㅇ','2023-02-15 07:55:33',1),(126,134,'baba','123123','2023-02-15 07:56:51',1),(127,134,'baba','asd','2023-02-15 07:57:44',1),(128,134,'baba','qweasdasd','2023-02-15 08:09:45',1),(129,133,'si44440','ㅇㅂㅈㅇㅂㅈㅇㅂㅈㅇㅂㅇㅂㅈ','2023-02-15 08:23:37',1),(130,134,'leejiyeon','sdf','2023-02-15 08:45:59',0),(131,134,'sj444440','wweee','2023-02-15 13:38:16',0),(132,134,'baba','hi321321323','2023-02-15 23:09:46',1),(133,134,'baba','안녕하세요','2023-02-15 23:13:02',0),(134,130,'ssafy2','asd','2023-02-16 01:33:21',1),(135,130,'ssafy2','asd','2023-02-16 01:34:47',1),(136,137,'ssafy','ㅇㅇㅇㅇ','2023-02-16 08:06:35',1);
/*!40000 ALTER TABLE `comment` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-02-17 11:32:51
